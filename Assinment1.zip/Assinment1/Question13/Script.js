let n1= prompt("Enter the first number");
let n2= prompt("Enter the second number");
let sum =n1+n2;
console.log("the sum = "+sum);