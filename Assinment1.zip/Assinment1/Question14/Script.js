let number =prompt("entet the number");
var fac =1
for(let i=1 ;i<=numer ; i++)
{
fac =fac*i;
}
console.log("the factorial of "+ number + " is"+ fac);