let n1 = prompt("Enter the first number ");
let n2= prompt("Enter the second number");
if(n1 >= 0 && n2<0) 
{
    console.log("YES ,The first number is Positive and the second number is negative");
}

else 
{
    console.log("False");
}