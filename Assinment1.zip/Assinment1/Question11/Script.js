let number =prompt("enter the number");
if(number>0)
{
console.log("the number is positive");
}
if(number<0)
{
console.log("the number is negative");
}
