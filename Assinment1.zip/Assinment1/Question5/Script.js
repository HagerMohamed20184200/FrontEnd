let n1= prompt("Enter the first number");
let n2= prompt("Enter the second number");
if (n1==50 || n2==50 || n1+n2==50)
{
console.log("True");
}
else
{
console.log("False");
}