let number = prompt("Enter the number ");

if(number %8==0) 
{
    console.log("The number is multiple of 8");
}

else if(number %5==0) 
{
    console.log("The number is multiple of 5");
}
else 
{
    console.log("not multiple of 8 or 5");
}