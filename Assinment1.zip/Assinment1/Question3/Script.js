let msg="welcome" ;
var newMsg = msg.split('').reverse().join('');
console.log(newMsg);