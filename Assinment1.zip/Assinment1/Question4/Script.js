let radius= prompt("Enter the radius");
let pi = 3.14;
let area = pi*radius*radius;
let Circumference= 2*pi*radius;
console.log("The Area = " +area);
console.log("The Circumference = " +Circumference);