var x = [1,2,3,4,5,6,7,8,9,10];
 
for (var  i =0 ; i < x.length; i++) 
{
   console.log("element: "  +i+" has number "+x[i]);
}
